import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration-table',
  templateUrl: './registration-table.component.html',
  styleUrls: ['./registration-table.component.css']
})
export class RegistrationTableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
