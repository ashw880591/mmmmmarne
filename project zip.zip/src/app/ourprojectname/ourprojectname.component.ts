import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ourprojectname',
  templateUrl: './ourprojectname.component.html',
  styleUrls: ['./ourprojectname.component.css']
})
export class OurprojectnameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
