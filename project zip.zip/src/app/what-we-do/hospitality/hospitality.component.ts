import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hospitality',
  templateUrl: './hospitality.component.html',
  styleUrls: ['./hospitality.component.css']
})
export class HospitalityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
