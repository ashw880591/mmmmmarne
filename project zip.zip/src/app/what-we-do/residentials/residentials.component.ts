import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-residentials',
  templateUrl: './residentials.component.html',
  styleUrls: ['./residentials.component.css']
})
export class ResidentialsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
