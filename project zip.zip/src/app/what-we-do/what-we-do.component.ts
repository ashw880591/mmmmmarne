import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-what-we-do',
  templateUrl: './what-we-do.component.html',
  styleUrls: ['./what-we-do.component.css']
})
export class WhatWeDoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    // this.loadAllImageDiv();
  }


  // loadAllImageDiv(id){
  //   document.getElementById(id).classList.add('activDiv');
  // }
}
